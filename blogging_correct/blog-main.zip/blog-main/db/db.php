<?php
$servername = "localhost";
$username = "root";
$password = " ";
$db_name = "navigdata";


// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->register.php);
}
echo "Connected successfully";
{
    $conn->login.php;
}
?>